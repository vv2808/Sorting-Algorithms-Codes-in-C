#include<stdio.h>
int main(){
    int arr[100],i,n,target,low,mid,high;
    printf("enter the number of elements in array: ");
    scanf("%d",&n);
    printf("Enter elements in array: ");
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    printf("Enter the number to be searched: ");
    scanf("%d",&target);
    low=0;
    high=n-1;
    while(high>=low){
        mid = (low+high)/2;
        if(arr[mid]==target){
            printf("Element found at %d",mid);
            break;
        }
        else if(arr[mid]<target){
            low=mid+1;
        }
        else{
            high=mid-1;
        }
    }
    return 0;
}
