/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    char s[100],r[100];
    int b,e,count=0;
    scanf("%s", s);
    while(s[count]!='\0')
       count++;
    e=count-1;
    for(b=0;b<count;b++)
    {
        r[b]=s[e];
        e--;
    }
    r[b]='\0';
    if(strcmp(s,r)==0)
    {
        printf("string is a palindrome");
    }
    else{
        printf("string is not a palindrome");
    }

    return 0;
}
